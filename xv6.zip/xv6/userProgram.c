#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "stat.h"
#define N 100

struct test {
    int number[128];
};

void printst(struct stat *st){
        printf(1, "st->type=%p \n",st->type);
        printf(1, "st->dev=%p \n",st->dev);
        printf(1, "st->ino=%p \n",st->ino);
        printf(1, "st->nlink=%p \n",st->nlink);
        printf(1, "st->size=%p \n",st->size);
				for(int i=0;i<13;i++){
						  printf(1, "st->start[%d]=%p st->length[%d]=%p\n",i,st->start[i],i,st->length[i]);
				}
}
int main(void)
{
    int fd;
    struct test t;/Users/home/Desktop/IIT_STUDY/cs450/450assignment3/xv6-public/usertests.c
    t.number[0] = 1;

    fd = open("file2",O_CREATE| O_RDWR|O_EXTENT);
    if(fd >= 0) {
        printf(1, "ok: create file succeed\n");
    } else {
        printf(1, "error: create file failed\n");
        exit();
    }

	for(int i=0;i<50;i++){   
		if(write(fd, &t, 512) != 512){
		    printf(1, "error: write to file failed\n");
		    exit();
		}
	}    
	struct stat st;
	fstat(fd,&st);
	printst(&st);
	lseek(fd,100);
	close(fd);
   exit();

}
